from datetime import datetime, timedelta
import json
from flask import request
from flask_jwt_extended import (
    get_jwt,
    get_jwt_identity,
    jwt_required
)
from flask_restful import Resource
from app.models import Tasks
from app.schemas.task import TaskSchema

task_schema = TaskSchema()
task_list_schema = TaskSchema(many=True)

class TaskResource(Resource):
    @classmethod
    def post(cls):
        task = task_schema.load(request.get_json())
        
        task.save_to_db()

        return {"message": "Task created successfully."}, 201
    

class TaskUpdateResource(Resource):
    @classmethod
    def put(cls, _id: int):
        task_json = request.get_json()

        task = Tasks.find_by_id(_id)


        if task:
            task.visibility = task_json["visibility"]
            task.taskname = task_json["taskname"]
            task.taskdescription = task_json["taskdescription"]
            task.save_to_db()
        else:
            return {"message": "comment not found"}, 404

        return task_schema.dump(task), 200
    
class TaskByUserResource(Resource):
    @classmethod
    def get(cls, _userid: int):
        task = Tasks.find_by_userid(_userid)
        if not task:
            return {"message": "no task found."}, 404
        return task_list_schema.dump(task), 200
    
class TaskByVisibilityResource(Resource):
    @classmethod
    def get(cls):
        task = Tasks.find_by_visibility()
        if not task:
            return {"message": "no task found."}, 404
        return task_list_schema.dump(task), 200
    
class DeleteTaskResource(Resource):
    @classmethod
    def delete(cls, _ID: int):
        task = Tasks.find_by_id(_ID)
        if task:
            task.delete_from_db()
            return {"message": "task deleted."}
        return {"message": "task not found."}, 404
